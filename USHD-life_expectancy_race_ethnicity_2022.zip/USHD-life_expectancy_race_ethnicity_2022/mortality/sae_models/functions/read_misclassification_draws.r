# Read in the misclassification draws and write them to the directory of interest.
# Used in prep_inputs.r
# The draws were created using generate_misclassification_draws.r

prep_misclass <- function(n.sims, dir){
  
  message("Using: FILEPATH")
  file.copy("FILEPATH", dir)

  return(expanded)
  
}


